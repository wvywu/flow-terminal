@echo off
cd /d "%~dp0"
if not exist C:\flowenv\Scripts\python.exe (
  echo Creating short-path environment C:\flowenv ...
  python -m venv C:\flowenv
)
echo Installing / checking packages...
C:\flowenv\Scripts\python.exe -m pip install -r requirements.txt
set PYTHONWARNINGS=ignore
echo Starting terminal... keep this window open.
C:\flowenv\Scripts\python.exe -m streamlit run terminal.py
pause
